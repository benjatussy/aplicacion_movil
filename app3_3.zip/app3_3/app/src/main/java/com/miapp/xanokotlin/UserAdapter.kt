package com.miapp.xanokotlin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.miapp.xanokotlin.databinding.ItemUserBinding
import com.miapp.xanokotlin.model.User

class UserAdapter(
    private var users: List<User>,
    private val onEditClick: (User) -> Unit,
    private val onBlockClick: (User) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    inner class UserViewHolder(private val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: User) {
            binding.tvUserName.text = user.name
            binding.tvUserEmail.text = user.email
            binding.tvUserStatus.text = "Estado: ${user.status}"

            binding.btnEditUser.setOnClickListener { onEditClick(user) }
            binding.btnBlockUser.setOnClickListener { onBlockClick(user) }

            // Cambiar texto del botón según el estado del usuario
            if (user.status.equals("bloqueado", ignoreCase = true)) {
                binding.btnBlockUser.text = "Desbloquear"
            } else {
                binding.btnBlockUser.text = "Bloquear"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(users[position])
    }

    override fun getItemCount(): Int = users.size

    fun updateUsers(newUsers: List<User>) {
        this.users = newUsers
        notifyDataSetChanged()
    }
}
