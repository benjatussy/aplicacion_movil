package com.miapp.xanokotlin.model

data class RegistroResponse(
    val authToken: String
)
