package com.miapp.xanokotlin

data class RegistroRequest(
    val name: String,
    val email: String,
    val password: String
)
