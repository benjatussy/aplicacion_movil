package com.miapp.xanokotlin

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.miapp.xanokotlin.api.ApiService
import com.miapp.xanokotlin.databinding.ActivityUserListBinding
import com.miapp.xanokotlin.model.User
import kotlinx.coroutines.launch

class UserListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserListBinding
    private lateinit var userAdapter: UserAdapter
    private lateinit var sessionManager: SessionManager
    private val apiService: ApiService by lazy {
        ApiService.createProductService() // CORRECCIÓN: Usar el servicio de datos/productos
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Gestionar Usuarios"

        sessionManager = SessionManager(this)
        setupRecyclerView()
        loadUsers()
    }

    private fun setupRecyclerView() {
        userAdapter = UserAdapter(emptyList(),
            onEditClick = { user ->
                // TODO: Implementar la lógica para editar un usuario
                Toast.makeText(this, "Editar usuario: ${user.name}", Toast.LENGTH_SHORT).show()
            },
            onBlockClick = { user ->
                // TODO: Implementar la lógica para bloquear/desbloquear un usuario
                val action = if (user.status.equals("bloqueado", ignoreCase = true)) "Desbloquear" else "Bloquear"
                Toast.makeText(this, "$action usuario: ${user.name}", Toast.LENGTH_SHORT).show()
            }
        )

        binding.rvUsers.apply {
            layoutManager = LinearLayoutManager(this@UserListActivity)
            adapter = userAdapter
        }
    }

    private fun loadUsers() {
        val token = sessionManager.getToken()
        if (token == null) {
            Toast.makeText(this, "Sesión expirada. Por favor, inicie sesión de nuevo.", Toast.LENGTH_LONG).show()
            // Lógica para redirigir al login
            return
        }

        lifecycleScope.launch {
            try {
                val response = apiService.getUsers("Bearer $token")
                if (response.isSuccessful && response.body() != null) {
                    val users = response.body()!!
                    userAdapter.updateUsers(users)
                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e("UserListActivity", "Error al cargar usuarios: ${response.code()} - $errorBody")
                    Toast.makeText(this@UserListActivity, "Error al cargar la lista de usuarios", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("UserListActivity", "Excepción al cargar usuarios", e)
                Toast.makeText(this@UserListActivity, "Error de conexión", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
