package com.miapp.xanokotlin.model

data class RegistroRequest(
    val name: String,
    val email: String,
    val password: String
)
