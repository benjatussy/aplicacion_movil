package com.miapp.xanokotlin.model

data class Meta(
    val width: Int,
    val height: Int
)
