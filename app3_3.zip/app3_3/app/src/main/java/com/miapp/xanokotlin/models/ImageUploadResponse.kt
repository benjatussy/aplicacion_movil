package com.miapp.xanokotlin.models

data class ProductRequest(
    val name: String,
    val team: String,
    val price: Int,
    val stock: Int,
    val description: String,
    val image_urls: List<ImageUploadResponse>
)
data class ImageUploadResponse(
    val access: String,
    val path: String,
    val name: String,
    val type: String,
    val size: Long,
    val mime: String,
    val meta: Meta
)

data class Meta(
    val width: Int,
    val height: Int
)
