package com.miapp.xanokotlin

import com.miapp.xanokotlin.models.ImageUploadResponse
import com.miapp.xanokotlin.models.Product
import com.miapp.xanokotlin.models.ProductRequest
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {

    @Multipart
    @POST("upload/image")
    suspend fun uploadImage(
        @Part image: MultipartBody.Part
    ): Response<ImageUploadResponse>

    @POST("shirt")
    suspend fun createProduct(
        @Body product: ProductRequest
    ): Response<Product>
}