package com.miapp.xanokotlin

data class LoginResponse(
    val authToken: String
)
