package com.miapp.xanokotlin

import com.miapp.xanokotlin.models.LoginResponse
import com.miapp.xanokotlin.models.User
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface AuthService {
    @POST("auth/login")
    suspend fun login(@Body credentials: Map<String, String>): Response<LoginResponse>

    @GET("auth/me")
    suspend fun getProfile(@Header("Authorization") token: String): Response<User>
}
