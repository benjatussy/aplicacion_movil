package com.miapp.xanokotlin

import com.miapp.xanokotlin.models.ImageUploadResponse
import com.miapp.xanokotlin.models.Product
import com.miapp.xanokotlin.models.ProductRequest
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.*

interface ProductService {
    @GET("shirt")
    suspend fun getProducts(): Response<List<Product>>

    @GET("shirt/{id}")
    suspend fun getProduct(@Path("id") id: Int): Response<Product>

    @POST("shirt")
    suspend fun createProduct(
        @Body product: ProductRequest
    ): Response<Product>

    @PUT("shirt/{id}")
    suspend fun updateProduct(@Path("id") id: Int, @Body product: Product): Response<Product>

    @DELETE("shirt/{id}")
    suspend fun deleteProduct(@Path("id") id: Int): Response<Unit>

    @Multipart
    @POST("upload/image")
    suspend fun uploadImage(@Part image: MultipartBody.Part): Response<ImageUploadResponse>
}
