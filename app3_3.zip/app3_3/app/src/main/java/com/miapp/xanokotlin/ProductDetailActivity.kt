package com.miapp.xanokotlin

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.tabs.TabLayoutMediator
import com.miapp.xanokotlin.api.ApiService
import com.miapp.xanokotlin.databinding.ActivityProductDetailBinding
import kotlinx.coroutines.launch

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductDetailBinding
    private lateinit var sessionManager: SessionManager
    private val apiService: ApiService by lazy { ApiService.createProductService() }
    private var productId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        productId = intent.getIntExtra("PRODUCT_ID", -1)

        if (productId != -1) {
            loadProductDetails()
        } else {
            Toast.makeText(this, "Error: ID de producto no encontrado", Toast.LENGTH_LONG).show()
            finish()
        }

        binding.btnDeleteProduct.setOnClickListener {
            deleteProduct()
        }

        binding.btnEditProduct.setOnClickListener {
            Toast.makeText(this, "Función de editar no implementada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadProductDetails() {
        lifecycleScope.launch {
            try {
                val response = apiService.getProduct(productId)
                if (response.isSuccessful && response.body() != null) {
                    val product = response.body()!!

                    // Configurar la información de texto
                    binding.tvProductNameDetail.text = product.name
                    binding.tvProductDescriptionDetail.text = product.description
                    binding.tvProductPriceDetail.text = "$${product.price}"
                    supportActionBar?.title = product.name

                    // Configurar el ViewPager2 con las imágenes
                    product.imageUrls?.let {
                        val imageAdapter = ImageSliderAdapter(it)
                        binding.viewPagerImages.adapter = imageAdapter

                        // Conectar el ViewPager con el TabLayout para los indicadores
                        TabLayoutMediator(binding.tabLayoutIndicator, binding.viewPagerImages) { tab, position ->
                            // Opcional: puedes configurar algo para cada tab aquí si quieres
                        }.attach()
                    }

                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e("ProductDetail", "Error al cargar producto: ${response.code()} - $errorBody")
                    Toast.makeText(this@ProductDetailActivity, "Error al cargar el producto", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("ProductDetail", "Excepción al cargar producto", e)
                Toast.makeText(this@ProductDetailActivity, "Error de conexión: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteProduct() {
        val token = sessionManager.getToken()
        if (token == null) {
            Toast.makeText(this, "Error de autenticación", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = apiService.deleteProduct(productId)
                if (response.isSuccessful) {
                    Toast.makeText(this@ProductDetailActivity, "Producto eliminado exitosamente", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e("ProductDetail", "Error al eliminar: ${response.code()} - $errorBody")
                    Toast.makeText(this@ProductDetailActivity, "Error al eliminar el producto", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("ProductDetail", "Excepción al eliminar", e)
                Toast.makeText(this@ProductDetailActivity, "Error de conexión: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
