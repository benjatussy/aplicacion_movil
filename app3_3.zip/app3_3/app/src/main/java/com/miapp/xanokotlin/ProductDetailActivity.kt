package com.miapp.xanokotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.miapp.xanokotlin.databinding.ActivityProductDetailBinding
import kotlinx.coroutines.launch

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductDetailBinding
    private lateinit var sessionManager: SessionManager
    private var productId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        productId = intent.getIntExtra("PRODUCT_ID", -1)

        if (productId != -1) {
            loadProductDetails()
        }

        binding.btnDeleteProduct.setOnClickListener {
            deleteProduct()
        }

        binding.btnEditProduct.setOnClickListener {
            // Por ahora, solo mostraremos un Toast.
            // La edición requeriría una nueva pantalla o un diálogo.
            Toast.makeText(this, "Función de editar no implementada", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadProductDetails() {
        lifecycleScope.launch {
            val token = sessionManager.getToken() ?: return@launch
            try {
                val response = ApiConfig.getProductService(token).getProduct(productId)
                if (response.isSuccessful && response.body() != null) {
                    val product = response.body()!!
                    binding.tvProductNameDetail.text = product.name
                    binding.tvProductDescriptionDetail.text = product.description
                    binding.tvProductPriceDetail.text = "$${product.price}"

                    val imageUrl = product.imageUrls?.firstOrNull()?.url
                    Glide.with(this@ProductDetailActivity)
                        .load(imageUrl)
                        .into(binding.imgProductDetail)
                } else {
                    Toast.makeText(this@ProductDetailActivity, "Error al cargar el producto", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ProductDetailActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteProduct() {
        lifecycleScope.launch {
            val token = sessionManager.getToken() ?: return@launch
            try {
                val response = ApiConfig.getProductService(token).deleteProduct(productId)
                if (response.isSuccessful) {
                    Toast.makeText(this@ProductDetailActivity, "Producto eliminado", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@ProductDetailActivity, "Error al eliminar el producto", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ProductDetailActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
