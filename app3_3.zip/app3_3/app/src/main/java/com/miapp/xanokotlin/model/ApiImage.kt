package com.miapp.xanokotlin.model

data class ApiImage(
    val url: String
)
