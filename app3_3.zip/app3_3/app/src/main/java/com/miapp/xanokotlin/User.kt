package com.miapp.xanokotlin

data class User(
    val name: String,
    val email: String
)
