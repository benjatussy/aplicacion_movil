package com.miapp.xanokotlin.models

data class User(
    val name: String,
    val email: String
)
