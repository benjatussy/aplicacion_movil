package com.miapp.xanokotlin.model

data class LoginRequest(
    val email: String,
    val password: String
)
