package com.miapp.xanokotlin

data class Meta(
    val width: Int,
    val height: Int
)
