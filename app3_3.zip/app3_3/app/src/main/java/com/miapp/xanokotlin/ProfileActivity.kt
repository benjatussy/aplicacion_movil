package com.miapp.xanokotlin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.miapp.xanokotlin.api.ApiService
import com.miapp.xanokotlin.databinding.ActivityProfileBinding
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private lateinit var sessionManager: SessionManager
    private val apiService: ApiService by lazy {
        ApiService.createAuthService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Perfil"

        sessionManager = SessionManager(this)
        loadProfile()

        binding.btnLogout.setOnClickListener {
            sessionManager.clear()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }

    private fun loadProfile() {
        val token = sessionManager.getToken()
        if (token == null) {
            Toast.makeText(this, "Error: Sesión no encontrada. Por favor, inicie sesión de nuevo.", Toast.LENGTH_LONG).show()
            // Opcional: redirigir a LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        lifecycleScope.launch {
            try {
                val response = apiService.getProfile("Bearer $token")
                if (response.isSuccessful && response.body() != null) {
                    val profile = response.body()!!
                    binding.tvUserName.text = profile.name
                    binding.tvUserEmail.text = profile.email
                } else {
                    val errorBody = response.errorBody()?.string()
                    Log.e("ProfileActivity", "Error al cargar perfil: ${response.code()} - $errorBody")
                    Toast.makeText(this@ProfileActivity, "Error al cargar el perfil.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("ProfileActivity", "Excepción al cargar perfil", e)
                Toast.makeText(this@ProfileActivity, "Error de conexión: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
