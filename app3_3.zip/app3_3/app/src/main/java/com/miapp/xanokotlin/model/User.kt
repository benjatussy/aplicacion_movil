package com.miapp.xanokotlin.model

import com.google.gson.annotations.SerializedName

data class User(
    val name: String,
    val email: String,
    @SerializedName("role") val rol: String,
    val status: String
)
