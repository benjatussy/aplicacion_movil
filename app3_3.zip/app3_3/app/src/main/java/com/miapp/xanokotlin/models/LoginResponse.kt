package com.miapp.xanokotlin.models

data class LoginResponse(
    val authToken: String
)
