package com.miapp.xanokotlin

import android.content.Context
import androidx.core.content.edit

class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)

    fun saveToken(token: String) {
        prefs.edit {
            putString("token", token)
        }
    }

    fun getToken(): String? = prefs.getString("token", null)

    fun clear() {
        prefs.edit {
            clear()
        }
    }
}
