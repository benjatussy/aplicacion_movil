package com.miapp.xanokotlin

data class ProfileResponse(
    val id: Int,
    val created_at: Long,
    val name: String,
    val email: String
)
